﻿"use strict";

var connection = new signalR.HubConnectionBuilder().withUrl("/chatHub").build();

//Disable send button until connection is established
document.getElementById("sendButton").disabled = true;
//document.getElementById("userInput").focus();

// read from cookie and set user if data is found
var rawCookie = document.cookie;
var cookie = "";
if (rawCookie == "") {
    document.getElementById("userInput").focus();
}
else {
    cookie = rawCookie.replace(";", "");
    cookie = cookie.replace("user=", "");
    document.getElementById("userInput").value = cookie;
}

connection.on("ReceiveMessage", function (user, message) {
    var li = document.createElement("li");
    document.getElementById("messagesList").appendChild(li);
    // We can assign user-supplied strings to an element's textContent because it
    // is not interpreted as markup. If you're assigning in any other way, you 
    // should be aware of possible script injection concerns.
    li.textContent = `<${user}> ${message}`;
});

connection.start().then(function () {
    document.getElementById("sendButton").disabled = false;
}).catch(function (err) {
    return console.error(err.toString());
});

document.getElementById("sendButton").addEventListener("click", function (event) {
    var user = document.getElementById("userInput").value;
    var message = document.getElementById("messageInput").value;

    // test if the values are empty
    if (user == "") {
        alert("Your username cannot be empty!")
        return;
    }
    if (message == "") {
        alert("Your message cannot be empty!")
        return;
    }

    // save username in cookie
    document.cookie = "user=" + user + "; expires=Thu, 18 Dec 2050 12:00:00 UTC";

    connection.invoke("SendMessage", user, message).catch(function (err) {
        return console.error(err.toString());
    });
    event.preventDefault();
    document.getElementById("messageInput").value = "";
    document.getElementById("messageInput").focus();
});