new features:
recent message log
tts mode
profanity filter
message clear
username and message char limit (20 and 200)
no space in username
press enter to send message
escape button