﻿"use strict";

var connection = new signalR.HubConnectionBuilder().withUrl("/chatHub").build();

//Disable send button until connection is established
document.getElementById("sendButton").disabled = true;
//document.getElementById("userInput").focus();

// read from cookie and set user if data is found
var rawCookie = document.cookie;
var cookie = "";
if (rawCookie == "") {
    document.getElementById("userInput").focus();
}
else {
    cookie = rawCookie.replace(";", "");
    cookie = cookie.replace("user=", "");
    document.getElementById("userInput").value = cookie;
}

// when enter is hit in the message box, it sends the message
document.getElementById("messageInput")
    .addEventListener("keyup", function (event) {
        event.preventDefault();
        if (event.keyCode === 13) {
            document.getElementById("sendButton").click();
        }
    });

// tts mode initialization
let speech = new SpeechSynthesisUtterance();
speech.lang = "en";
var voices = window.speechSynthesis.getVoices();
speech.voice = voices[4];
window.speechSynthesis.speak(speech);

connection.on("ReceiveMessage", function (user, message) {
    var li = document.createElement("li");
    document.getElementById("messagesList").appendChild(li);
    // We can assign user-supplied strings to an element's textContent because it
    // is not interpreted as markup. If you're assigning in any other way, you 
    // should be aware of possible script injection concerns.
    //li.textContent = `<${user}> ${message}`;

    // profanity filter
    // doesnt work :(
    //#region old filter
    /*
    if (document.getElementById("filterMode").checked == true) {
        var checkedUser = user;
        var checkedMessage = message;

        // initialize regex
        //#region bad words
        const badWords = ["fuck", "shit", "bitch", "ass", "nigger", "nigga"];
        //#endregion
        const reEscape = s => s.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
        const badWordsRE = new RegExp(badWords.map(reEscape).join('|'));

        var bwUser = checkedUser.match(badWordsRE)
        var bwMessage = checkedMessage.match(badWordsRE)

        // character to censor with
        var censorChar = "*";
        alert(bwUser.toString + " | " + bwMessage.toString);

        for (let i in bwUser) {
            var censor = "";
            for (let x = 0; x == i.length; x++) { censor += censorChar; }
            alert("1");
            checkedUser = checkedUser.replace(i, censor);
            alert("2");
        }
        for (let i in bwMessage) {
            var censor = "e";
            //for (let x = 0; x == i.length; x++) { censor += censorChar; }
            alert("3" + censor);
            checkedMessage = message.replace(i, censor);
            alert("4");
        }

        // update the message li
        li.textContent = `<${checkedUser}> ${checkedMessage}`;
    }
    */
    //#endregion

    var checkedUser = user;
    var checkedMessage = message;
    if (document.getElementById("filterMode").checked == true) {
        //#region BAD WORDS
        checkedUser = checkedUser.replaceAll(/fuck/img, "****");
        checkedUser = checkedUser.replaceAll(/bitch/img, "*****");
        checkedUser = checkedUser.replaceAll(/ass/img, "***");
        checkedUser = checkedUser.replaceAll(/shit/img, "****");
        checkedUser = checkedUser.replaceAll(/nigger/img, "******");
        checkedUser = checkedUser.replaceAll(/nigga/img, "*****");

        checkedMessage = checkedMessage.replaceAll(/fuck/img, "****");
        checkedMessage = checkedMessage.replaceAll(/bitch/img, "*****");
        checkedMessage = checkedMessage.replaceAll(/ass/img, "***");
        checkedMessage = checkedMessage.replaceAll(/shit/img, "****");
        checkedMessage = checkedMessage.replaceAll(/nigger/img, "******");
        checkedMessage = checkedMessage.replaceAll(/nigga/img, "*****");
        //#endregion
    }

    // tts mode
    if (document.getElementById("ttsMode").checked == true) {
        speech.text = user + " says " + message;
        window.speechSynthesis.speak(speech);
    }

    li.textContent = `<${checkedUser}> ${checkedMessage}`;
});

connection.start().then(function () {
    document.getElementById("sendButton").disabled = false;

    // login to hub
    connection.invoke("Login", document.getElementById("userInput").value).catch(function (err) {
        return console.error(err.toString());
    });

}).catch(function (err) {
    return console.error(err.toString());
});

document.getElementById("sendButton").addEventListener("click", function (event) {
    var user = document.getElementById("userInput").value;
    var message = document.getElementById("messageInput").value;

    // test if the values are empty
    if (user == "") {
        alert("Your username cannot be empty!")
        return;
    }
    if (message == "") {
        alert("Your message cannot be empty!")
        return;
    }
    if (user.length > 20) {
        alert("Your username cannot be more than 20 characters!")
        return;
    }
    if (message.length > 200) {
        alert("Your message cannot be more than 200 characters!")
        return;
    }
    if (user.includes(" ")) {
        alert("Your username cannot contain a space!")
        return;
    }

    // save username in cookie
    document.cookie = "user=" + user + "; expires=Thu, 18 Dec 2050 12:00:00 UTC";

    connection.invoke("SendMessage", user, message).catch(function (err) {
        return console.error(err.toString());
    });
    event.preventDefault();
    document.getElementById("messageInput").value = "";
    document.getElementById("messageInput").focus();
});

// control options visibility
document.getElementById("toggleOptions").addEventListener("click", function (event) {
    var toggleOptions = document.getElementById("toggleOptions");
    if (toggleOptions.value == "Show Options") {
        toggleOptions.value = "Hide Options"
        document.getElementById("ttsModeDiv").style.display = "initial";
        document.getElementById("filterModeDiv").style.display = "initial";
        document.getElementById("clearMsgDiv").style.display = "initial";
    }
    else if (toggleOptions.value == "Hide Options") {
        toggleOptions.value = "Show Options"
        document.getElementById("ttsModeDiv").style.display = "none";
        document.getElementById("filterModeDiv").style.display = "none";
        document.getElementById("clearMsgDiv").style.display = "none";
    }
    else { }
});

// filter mode toggle thing
document.getElementById("filterMode").addEventListener("click", function (event) {
    if (document.getElementById("filterMode").checked == true) {
        var x = document.querySelectorAll("li");

        for (let i = 0; i < x.length; i++) {
            //#region BAD WORDS
            x[i].textContent = x[i].textContent.replaceAll(/fuck/img, "f***");
            x[i].textContent = x[i].textContent.replaceAll(/bitch/img, "b****");
            x[i].textContent = x[i].textContent.replaceAll(/ass/img, "a**");
            x[i].textContent = x[i].textContent.replaceAll(/shit/img, "s***");
            x[i].textContent = x[i].textContent.replaceAll(/nigger/img, "n*****");
            x[i].textContent = x[i].textContent.replaceAll(/nigga/img, "n****");
            x[i].textContent = x[i].textContent.replaceAll(/faggot/img, "f*****");
            //#endregion
        }
    }
    else {
        var x = document.querySelectorAll("li");

        for (let i = 0; i < x.length; i++) {
            //#region BAD WORDS
            x[i].textContent = x[i].textContent.replaceAll(/f\*\*\*/img, "fuck");
            x[i].textContent = x[i].textContent.replaceAll(/b\*\*\*\*/img, "bitch");
            x[i].textContent = x[i].textContent.replaceAll(/a\*\*/img, "ass");
            x[i].textContent = x[i].textContent.replaceAll(/s\*\*\*/img, "shit");
            x[i].textContent = x[i].textContent.replaceAll(/n\*\*\*\*\*/img, "nigger");
            x[i].textContent = x[i].textContent.replaceAll(/n\*\*\*\*/img, "nigga");
            x[i].textContent = x[i].textContent.replaceAll(/f\*\*\*\*\*/img, "faggot");
            //#endregion
        }
    }
});

document.getElementById("clearMsgList").addEventListener("click", function (event) {
    var ul = document.getElementById("messagesList");
    while (ul.firstChild) {
        ul.removeChild(ul.firstChild)
    }
});