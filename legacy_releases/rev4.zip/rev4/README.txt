new features:
updated profanity filter
show uids mode
changed gui
connection status >
	reconnect feature
	connection status updates frequently
backend updates >
	added uids
	logs show uids
	uids are stored with recent messages